import random
import secrets
class AES_Algorithm:
    SubNib_Table = [
    ['63', '7c', '77', '7b', 'f2', '6b', '6f', 'c5', '30', '01', '67', '2b', 'fe', 'd7', 'ab', '76'],
    ['ca', '82', 'c9', '7d', 'fa', '59', '47', 'f0', 'ad', 'd4', 'a2', 'af', '9c', 'a4', '72', 'c0'],
    ['b7', 'fd', '93', '26', '36', '3f', 'f7', 'cc', '34', 'a5', 'e5', 'f1', '71', 'd8', '31', '15'],
    ['04', 'c7', '23', 'c3', '18', '96', '05', '9a', '07', '12', '80', 'e2', 'eb', '27', 'b2', '75'],
    ['09', '83', '2c', '1a', '1b', '6e', '5a', 'a0', '52', '3b', 'd6', 'b3', '29', 'e3', '2f', '84'],
    ['53', 'd1', '00', 'ed', '20', 'fc', 'b1', '5b', '6a', 'cb', 'be', '39', '4a', '4c', '58', 'cf'],
    ['d0', 'ef', 'aa', 'fb', '43', '4d', '33', '85', '45', 'f9', '02', '7f', '50', '3c', '9f', 'a8'],
    ['51', 'a3', '40', '8f', '92', '9d', '38', 'f5', 'bc', 'b6', 'da', '21', '10', 'ff', 'f3', 'd2'],
    ['cd', '0c', '13', 'ec', '5f', '97', '44', '17', 'c4', 'a7', '7e', '3d', '64', '5d', '19', '73'],
    ['60', '81', '4f', 'dc', '22', '2a', '90', '88', '46', 'ee', 'b8', '14', 'de', '5e', '0b', 'db'],
    ['e0', '32', '3a', '0a', '49', '06', '24', '5c', 'c2', 'd3', 'ac', '62', '91', '95', 'e4', '79'],
    ['e7', 'c8', '37', '6d', '8d', 'd5', '4e', 'a9', '6c', '56', 'f4', 'ea', '65', '7a', 'ae', '08'],
    ['ba', '78', '25', '2e', '1c', 'a6', 'b4', 'c6', 'e8', 'dd', '74', '1f', '4b', 'bd', '8b', '8a'],
    ['70', '3e', 'b5', '66', '48', '03', 'f6', '0e', '61', '35', '57', 'b9', '86', 'c1', '1d', '9e'],
    ['e1', 'f8', '98', '11', '69', 'd9', '8e', '94', '9b', '1e', '87', 'e9', 'ce', '55', '28', 'df'],
    ['8c', 'a1', '89', '0d', 'bf', 'e6', '42', '68', '41', '99', '2d', '0f', 'b0', '54', 'bb', '16']
    ]    
    Inv_SubNib_Table = [
    ['52', '09', '6A' ,'D5', '30', '36', 'A5', '38', 'BF', '40', 'A3', '9E', '81', 'F3', 'D7' ,'FB' ],
    ['7C', 'E3', '39', '82', '9B', '2F', 'FF', '87', '34', '8E', '43', '44', 'C4', 'DE', 'E9', 'CB' ],
    ['54', '7B', '94', '32' ,'A6' ,'C2', '23', '3D' ,'EE' ,'4C', '95', '0B' ,'42', 'FA', 'C3', '4E' ],
    ['08', '2E', 'A1', '66', '28' ,'D9', '24', 'B2', '76', '5B', 'A2', '49', '6D', '8B', 'D1', '25' ],
    ['72' ,'F8', 'F6', '64', '86', '68', '98', '16', 'D4', 'A4', '5C' ,'CC' ,'5D', '65', 'B6', '92' ],
    ['6C', '70', '48', '50', 'FD', 'ED', 'B9', 'DA', '5E', '15', '46', '57', 'A7', '8D', '9D', '84' ],
    ['90', 'D8', 'AB', '00', '8C', 'BC', 'D3', '0A', 'F7', 'E4', '58', '05', 'B8', 'B3', '45', '06' ],
    ['D0', '2C', '1E', '8F', 'CA', '3F' ,'0F', '02', 'C1', 'AF', 'BD', '03', '01', '13', '8A', '6B' ],
    ['3A', '91', '11', '41', '4F' ,'67', 'DC', 'EA', '97', 'F2', 'CF', 'CE', 'F0', 'B4', 'E6', '73' ],
    ['96', 'AC', '74', '22', 'E7', 'AD', '35', '85', 'E2', 'F9', '37', 'E8', '1C', '75', 'DF', '6E' ],
    ['47', 'F1', '1A', '71', '1D', '29', 'C5', '89', '6F', 'B7', '62', '0E', 'AA', '18', 'BE', '1B' ],
    ['FC', '56', '3E', '4B', 'C6', 'D2', '79', '20', '9A' ,'DB', 'C0', 'FE', '78', 'CD', '5A', 'F4' ],
    ['1F', 'DD', 'A8', '33', '88', '07', 'C7', '31', 'B1', '12', '10', '59', '27', '80', 'EC', '5F' ],
    ['60', '51', '7F', 'A9', '19', 'B5', '4A', '0D', '2D', 'E5', '7A', '9F', '93', 'C9', '9C', 'EF' ],
    ['A0', 'E0', '3B', '4D', 'AE', '2A', 'F5', 'B0', 'C8', 'EB', 'BB', '3C', '83', '53', '99', '61' ],        
    ['17', '2B', '04', '7E', 'BA', '77', 'D6', '26', 'E1', '69', '14', '63', '55', '21', '0C', '7D' ]
    ]

    MixColumns_Tabel=[
        ['02','03','01','01'],
        ['01','02','03','01'],
        ['01','01','02','03'],
        ['03','01','01','02']
        ]
    Inv_MixColumns_Tabel=[
        ['0E','0B','0D','09'],
        ['09','0E','0B','0D'],
        ['0D','09','0E','0B'],
        ['0B','0D','09','0E']
        ]
    Rcon=['01000000', '02000000', '04000000', '08000000', '10000000', '20000000', '40000000', '80000000', '1b000000', '36000000']
    WKey=[]


    def decimal_to_4bit_binary(number):    
        binary_representation = bin(number)[2:]    
        binary_representation = binary_representation.zfill(4)
        return binary_representation


    def xor_binary_strings(str1, str2):    
        result = ''.join('1' if bit1 != bit2 else '0' for bit1, bit2 in zip(str1, str2))
        return result
    
    def xor_hex_strings(hex_str1, hex_str2):
        try:            
            int_value1 = int(hex_str1, 16)
            int_value2 = int(hex_str2, 16)            
            result = int_value1 ^ int_value2            
            hex_result = format(result, 'x')            
            hex_result = hex_result.rjust(len(hex_str2), '0')
            return hex_result
        except ValueError:
            print("Invalid hexadecimal string")

        
    def binary_to_decimal_4bit(binary_str):    
        decimal_number = int(binary_str, 2)
        return decimal_number

    def RotNib(binary_str):   
        length = len(binary_str)         
        swapped_str = binary_str[2:4]+binary_str[4:6]+binary_str[6:8]+binary_str[0:2]
        return swapped_str 


    def SubNib(self,Key,SubNib):
        length=len(Key) 
        arr=""        
        for i in range(0,length,2):            
            one=self.hex_to_decimal(Key[i])            
            two=self.hex_to_decimal(Key[i+1]) 
            one=SubNib[one][two]              
            arr+=one
        return arr
    
    

    def Auxiliary(self,w1,num,SubNib):
        rnib=self.RotNib(w1)               
        snib=self.SubNib(self,rnib,SubNib)           
        result=self.xor_hex_strings(snib,num) 
        return result      


    def Generate_Keys(self, Key,SubNib): 
        length=len(Key) 
        w=[]
        j=0
        for i in range(0,length,8):
            w.append(Key[i:i+8])
        for i in range(10):
            z=self.Auxiliary(self,w[len(w)-1],self.Rcon[i],SubNib)   
            w.append(self.xor_hex_strings(w[j],z))
            j+=1
            for k in range(3):                     
                w.append(self.xor_hex_strings(w[j],w[len(w)-1]))
                j+=1
        for i in range(0,len(w),4):
            string=""
            string+=w[i]+w[i+1]+w[i+2]+w[i+3]            
            self.WKey.append(string)


   

    def key_to_matrix(key):        
        if len(key) != 32:
            print("Invalid key length")
            return None        
        matrix = [['00' for _ in range(4)] for _ in range(4)]        
        for col in range(4):
            for row in range(4):
                index = col * 8 + row * 2
                matrix[row][col] = key[index:index+2]

        return matrix

    def shift_rows(state_matrix):
        for row in range(1, 4):
            state_matrix[row] = state_matrix[row][row:] + state_matrix[row][:row]
        return state_matrix

    def ShiftRows(self,Key): 
        matrix= self.key_to_matrix(Key)    
        shifted_matrix=self.shift_rows(matrix) 
        result = ''.join([''.join(column) for column in zip(*shifted_matrix)])                 
        return result

    def hex_to_decimal(hex_string):
        try:
            decimal_value = int(hex_string, 16)
            return decimal_value
        except ValueError:
            print("Invalid hexadecimal string")


    def hex_to_binary(hex_string):
        decimal_value = int(hex_string, 16)
        binary_representation = bin(decimal_value)[2:]  
        binary_representation = binary_representation.zfill(8)
        return binary_representation

    def return_x(Key):
        length=len(Key)              
        arr=[]
        for i in range(0,length):  
            if Key[i] =='1':
                string=str(7-i)
                arr.append(string)
        return arr
        
    def do_op(y,z):
        length=len(z)
        op=[]
        for v in y:
            for k in range(0,length):
                if v!='0':
                    op.append(str(int(z[k])+int(v)))
                else:                            
                    op.append(z[k])
        return op
    
    def do_sec_op(op):
        one=[]
        for value in op:
            if value=='10':
                one.append('6')
                one.append('5')
                one.append('3')
                one.append('2')
            else:
                if value=='9':
                    one.append('5')
                    one.append('4')
                    one.append('2')
                    one.append('1')
                else: 
                    if value=='8':
                        one.append('4')
                        one.append('3')
                        one.append('1')
                        one.append('0')
                    else:
                        one.append(value)

        return one
    
    def remove_duplicates(array):
        result_array = []

        for element in array:
            # print(array.count(element))
            if array.count(element)%2!=0 and array.count(element)==1:
                # print(array.count(element),element)
                result_array.append(element)        
            else:
                
                if element not in result_array and array.count(element)%2!=0 :
                    # print(array.count(element),element)
                    result_array.append(element)
                    
            

        return result_array

    def final_op(op):
        zero = '00000000'
        result_list = list(zero)

        for element in op:
            index = int(element)
            result_list[7-index] = '1'

        result_string = ''.join(result_list)        
        return result_string
       
    def binary_to_hex(binary_string):
        hex_result = hex(int(binary_string, 2))[2:]
        return hex_result
        

    def MixColumn(self,Key):                          
        matrix= self.key_to_matrix(Key)
        s=[]                
        numbers=[]
        for i in range(len(matrix)):
            for j in range(len(matrix[0])):
                op=[]
                # print("matrix:",matrix[j][0],self.MixColumns_Tabel[i][j])
                z=self.hex_to_binary(matrix[j][0])
                z=self.return_x(z)                                
                y=self.hex_to_binary(self.MixColumns_Tabel[i][j])
                y=self.return_x(y)                                       
                op=self.do_op(y,z)   
                # print("y,z,op",y,z,op)
                op=self.remove_duplicates(op)                                          
                op=self.do_sec_op(op)
                # print("op after 2:",op)                 
                op=self.remove_duplicates(op)   
                            
                number=self.final_op(op) 
                            
                numbers.append(number)             
                # print("numbers:",number)
            # print("numbers list:",numbers) 
            number=self.xor_hex_strings(numbers[0],numbers[1])
            # print("after xor:",number)    
            for j in range(2,len(numbers)): 
                number=self.xor_hex_strings(number,numbers[j])
                
                # print(numbers,number) 
            # print("final number:",number)
            s.append(number)
            numbers.clear()
            for j in range(len(matrix[0])):
                op=[]
                # print("matrix:",matrix[j][1],self.MixColumns_Tabel[i][j])
                z=self.hex_to_binary(matrix[j][1])
                z=self.return_x(z)                                
                y=self.hex_to_binary(self.MixColumns_Tabel[i][j])
                y=self.return_x(y)                                       
                op=self.do_op(y,z)   
                # print("y,z,op",y,z,op)
                op=self.remove_duplicates(op)                                          
                op=self.do_sec_op(op)
                # print("op after 2:",op)            
                op=self.remove_duplicates(op)   
                            
                number=self.final_op(op) 
                # print(op)      
                numbers.append(number)             
                # print("numbers:",number)
            # print("numbers list:",numbers)  
            number=self.xor_hex_strings(numbers[0],numbers[1])
            # print("after xor:",number)     
            for j in range(2,len(numbers)): 
                number=self.xor_hex_strings(number,numbers[j])
                
                # print(numbers,number) 
            # print("final number:",number)
            s.append(number)
            numbers.clear()
            for j in range(len(matrix[0])):
                op=[]
                # print("matrix:",matrix[j][2],self.MixColumns_Tabel[i][j])
                z=self.hex_to_binary(matrix[j][2])
                z=self.return_x(z)                                
                y=self.hex_to_binary(self.MixColumns_Tabel[i][j])
                y=self.return_x(y)                                       
                op=self.do_op(y,z)   
                # print("y,z,op",y,z,op)
                op=self.remove_duplicates(op)       
                op=self.do_sec_op(op)
                # print("op after 2:",op)               
                op=self.remove_duplicates(op)   
                            
                number=self.final_op(op) 
                            
                numbers.append(number)             
                # print("numbers:",number)
            # print("numbers list:",numbers)  
            number=self.xor_hex_strings(numbers[0],numbers[1])
            # print("after xor:",number)   
            for j in range(2,len(numbers)): 
                number=self.xor_hex_strings(number,numbers[j])
                
                # print(numbers,number) 
            # print("final number:",number)
            s.append(number)
            numbers.clear()
            for j in range(len(matrix[0])):
                op=[]
                # print("matrix:",matrix[j][3],self.MixColumns_Tabel[i][j])
                z=self.hex_to_binary(matrix[j][3])
                z=self.return_x(z)                                
                y=self.hex_to_binary(self.MixColumns_Tabel[i][j])
                y=self.return_x(y)                                       
                op=self.do_op(y,z)   
                # print("y,z,op",y,z,op)
                op=self.remove_duplicates(op)                             
                op=self.do_sec_op(op)
                # print("op after 2:",op)                  
                op=self.remove_duplicates(op)   
                            
                number=self.final_op(op) 
                            
                numbers.append(number)             
                # print("numbers:",number)
            # print("numbers list:",numbers)   
            number=self.xor_hex_strings(numbers[0],numbers[1])
            # print("after xor:",number)    
            for j in range(2,len(numbers)): 
                number=self.xor_hex_strings(number,numbers[j])
                
                # print(numbers,number) 
            # print("final number:",number)
            s.append(number)              
            numbers.clear()    
        for i in range(len(s)):
            s[i]=self.binary_to_hex(s[i])            
            if len(s[i])!=2:
                s[i]="0"+s[i]
            key_matrix = [
            [s[0],s[1],s[2],s[3]],
            [s[4],s[5],s[6],s[7]],
            [s[8],s[9],s[10],s[11]],
            [s[12],s[13],s[14],s[15]]

        ]

        # Convert the 4x4 matrix back to a key
        key = ''.join([''.join(column) for column in zip(*key_matrix)])
        return key                                                             


    def Inv_shift_rows(state_matrix):
        for row in range(1, 4):
            state_matrix[row] = state_matrix[row][-row:] + state_matrix[row][:-row]
        return state_matrix
    
    def Inv_ShiftRows(self,Key):         
        matrix= self.key_to_matrix(Key)    
        shifted_matrix=self.Inv_shift_rows(matrix) 
        result = ''.join([''.join(column) for column in zip(*shifted_matrix)])                 
        return result

                        
    
        
        

    def Inv_MixColumn(self,Key):                          
        matrix= self.key_to_matrix(Key)
        s=[]                
        numbers=[]
        for i in range(len(matrix)):
            for j in range(len(matrix[0])):
                op=[]
                # print("matrix:",matrix[j][0],self.Inv_MixColumns_Tabel[i][j])
                z=self.hex_to_binary(matrix[j][0])
                z=self.return_x(z)                                
                y=self.hex_to_binary(self.Inv_MixColumns_Tabel[i][j])
                y=self.return_x(y)                                       
                op=self.do_op(y,z)   
                # print("y,z,op:",y,z,op)
                op=self.remove_duplicates(op)  
                # print("duplicates:",op)      
                op=self.do_sec_op(op)
                # print("second:",op)                 
                op=self.remove_duplicates(op)   
                # print("duplicates:",op)
                number=self.final_op(op)                 
                numbers.append(number)             
                # print("numbers:",number)
            # print("list:",numbers) 
            number=self.xor_hex_strings(numbers[0],numbers[1])
            # print(number)    
            for j in range(2,len(numbers)): 
                number=self.xor_hex_strings(number,numbers[j])
                
                # print(numbers,number) 
            # print("final:",number)
            s.append(number)
            numbers.clear()
            for j in range(len(matrix[0])):
                op=[]
                # print("matrix:",matrix[j][1],self.Inv_MixColumns_Tabel[i][j])
                z=self.hex_to_binary(matrix[j][1])
                z=self.return_x(z)                                
                y=self.hex_to_binary(self.Inv_MixColumns_Tabel[i][j])
                y=self.return_x(y)                                       
                op=self.do_op(y,z)   
                # print("y,z,op:",y,z,op)
                op=self.remove_duplicates(op)
                # print("duplicates:",op)             
                op=self.do_sec_op(op)
                # print("second:",op)            
                op=self.remove_duplicates(op)   
                # print("duplicates:",op)
                number=self.final_op(op) 
                # print(op)      
                numbers.append(number)             
                # print("numbers:",number)
            # print("list:",numbers) 
            number=self.xor_hex_strings(numbers[0],numbers[1])
            # print(number)    
            for j in range(2,len(numbers)): 
                number=self.xor_hex_strings(number,numbers[j])
                
                # print(numbers,number) 
            # print("final:",number)
            s.append(number)
            numbers.clear()
            for j in range(len(matrix[0])):
                op=[]
                # print("matrix:",matrix[j][2],self.Inv_MixColumns_Tabel[i][j])
                z=self.hex_to_binary(matrix[j][2])
                z=self.return_x(z)                                
                y=self.hex_to_binary(self.Inv_MixColumns_Tabel[i][j])
                y=self.return_x(y)                                       
                op=self.do_op(y,z)   
                # print("y,z,op:",y,z,op)
                op=self.remove_duplicates(op)  
                # print("duplicates:",op) 
                op=self.do_sec_op(op)
                # print("second:",op)               
                op=self.remove_duplicates(op)   
                # print("duplicates:",op)
                number=self.final_op(op) 
                            
                numbers.append(number)             
                # print("numbers:",number)
            # print("list:",numbers)
            number=self.xor_hex_strings(numbers[0],numbers[1])
            # print(number)    
            for j in range(2,len(numbers)): 
                number=self.xor_hex_strings(number,numbers[j])
                
                # print(numbers,number) 
            # print("final:",number)
            s.append(number)
            numbers.clear()
            for j in range(len(matrix[0])):
                op=[]
                # print("matrix:",matrix[j][3],self.Inv_MixColumns_Tabel[i][j])
                z=self.hex_to_binary(matrix[j][3])
                z=self.return_x(z)                                
                y=self.hex_to_binary(self.Inv_MixColumns_Tabel[i][j])
                y=self.return_x(y)                                       
                op=self.do_op(y,z)   
                # print("y,z,op:",y,z,op)
                op=self.remove_duplicates(op) 
                # print("duplicates:",op)
                op=self.do_sec_op(op)
                # print("second:",op)                  
                op=self.remove_duplicates(op)   
                # print("duplicates:",op)
                number=self.final_op(op) 
                            
                numbers.append(number)             
                # print("numbers:",number)
            # print("list:",numbers)
            number=self.xor_hex_strings(numbers[0],numbers[1])
            # print(number)    
            for j in range(2,len(numbers)): 
                number=self.xor_hex_strings(number,numbers[j])
                
                # print(numbers,number) 
            # print("final:",number)
            s.append(number)              
            numbers.clear()    
        for i in range(len(s)):
            s[i]=self.binary_to_hex(s[i])
            if len(s[i])!=2:
                s[i]="0"+s[i]
            key_matrix = [
            [s[0],s[1],s[2],s[3]],
            [s[4],s[5],s[6],s[7]],
            [s[8],s[9],s[10],s[11]],
            [s[12],s[13],s[14],s[15]]

        ]

        # Convert the 4x4 matrix back to a key
        key = ''.join([''.join(column) for column in zip(*key_matrix)])
        return key         

    # 61686d65640000000000000000000000
    def Encrypt(self,key,plaintext):
        self.WKey.clear()        
        self.Generate_Keys(self, key,self.SubNib_Table)          
        # print(self.WKey)      
        for i in range(10):
            round=self.xor_hex_strings(plaintext,self.WKey[i])
            # print("after xor",round)                     
            round=self.SubNib(self,round,self.SubNib_Table) 
            # print("after subnib",round) 
            #print("after ",round)                         
            round= self.ShiftRows(self,round)                        
            # print("after shift",round)
            if i+1!=10:
                round= self.MixColumn(self,round)
                # print("after mix",round)  
            # Write content to the file
                
            plaintext=round  
            # print(round)                   
        return self.xor_hex_strings(plaintext,self.WKey[len(self.WKey)-1])
    
    
    def Decrypt(self,key,cyphertext):
        self.WKey.clear()        
        self.Generate_Keys(self, key,self.Inv_SubNib_Table) 
        plaintext=cyphertext  
        n=len(self.WKey)-1
        # print(n)
        round=self.xor_hex_strings(plaintext,self.WKey[n])
        for i in range(10):            
            n-=1 
            round= self.Inv_ShiftRows(self,round) 
            round=self.SubNib(self,round,self.Inv_SubNib_Table)               
            round=self.xor_hex_strings(plaintext,self.WKey[n])      
            # print(n)                   
            if i+1!=10:
                round= self.Inv_MixColumn(self,round)
                # print("afteri mix",round)                         
            plaintext=round                         
            # print(round)                        
        return plaintext                           
class RC4_Algorithm:
    s=""
    t=""
    def Generate_S_T(self,k):
        self.s = list(range(8)) 
        num=0
        for i in range(8): 
            if num==4:
                num=0
            self.t += k[num]
            num+=1


    def Initial_Permutation(s,t):
        j = 0
        for i in range(8):
            j = (j + s[i] + int(t[i])) % 8  
            s[i], s[j] = s[j], s[i]

        s = [int(i) for i in s]
        return s
            
    
    def encrypt(self,p, k):   
        self.Generate_S_T(self,k)   
        s=self.Initial_Permutation(self.s,self.t)          
        i, j = 0, 0 
        arr =""
        m = 0
        while m < len(p):
            i = (i + 1) % 8
            j = (j + s[i]) % 8
            s[i], s[j] = s[j], s[i]

            t = (s[i] + s[j]) % 8
            k = s[t]
            result = int(k) ^ int(p[m])
            arr+=str(result)
            m += 1
        return arr

    def decrypt(self,c, k):
        self.Generate_S_T(self,k)   
        s=self.Initial_Permutation(self.s,self.t) 
        i, j = 0, 0 
        arr = ""
        m = 0
        while m < len(c):
            i = (i + 1) % 8
            j = (j + s[i]) % 8
            s[i], s[j] = s[j], s[i]

            t = (s[i] + s[j]) % 8
            k = s[t]
            result = int(k) ^ int(c[m])
            arr+=str(result)
            m += 1

        return arr
class ELGAMAL_Algorithm:
    def generate_random_value(value):        
        random_value = random.randint(1, value - 1)
        return random_value


    def encrypt(self,ttp,Message):
        k_small=self.generate_random_value(ttp.q)
        # Calculate public key ya = a^xa mod q
        ya = pow(ttp.alpha, ttp.PrivateKey, ttp.q)

        # Calculate k_new = ya^k mod q
        k_new = pow(ya, k_small, ttp.q)

        # Calculate C1 = a^k mod q
        c1 = pow(ttp.alpha, k_small, ttp.q)

        # Calculate C2 = KM mod q
        c2 = (k_new * Message) % ttp.q

        # Verify k_new
        k_t2ked = pow(c1, ttp.PrivateKey, ttp.q)
        if k_t2ked == k_new:
            return k_t2ked,c2
        else:
            return None

    def decrypt(ttp,Cypher_text,c2):
        # Calculate the modular inverse of k_new
        k_1 = pow(Cypher_text, -1, ttp.q)

        # Decrypt to obtain M_t2ked = C2 * k_1 mod q
        M_t2ked = (c2 * k_1) % ttp.q
        return M_t2ked        
class TTP_Algorithm:
    p=""
    q=""
    alpha=""
    PrivateKey=""
    PublicKey=""
    def is_prime(num):    
        if num < 2:
            return False
        for i in range(2, int(num**0.5) + 1):
            if num % i == 0:
                return False
        return True

    #generate prime numebr
    def generate_random_prime(self):
        while True:
            num = random.randrange(101, 1000)  
            if self.is_prime(num):
                return num

    #alpha
    def alphaa(q):

        for alpha in range(2, q):
            is_primitive_root = True

            for i in range(1, q - 1):
                if pow(alpha, i, q) == 1:
                    is_primitive_root = False
                    break

            if is_primitive_root:
                return alpha

    #xA , xB     
    def Calc_xA_and_xB(q):
        x  = secrets.randbelow(q - 1) + 1
        return x

    #yA , yB , PrivKey
    def Calc_yA_and_yB_PrivKey(alpha, XA, q):
        y = pow(alpha, XA, q)
        return y
class RSA_Algorithm:
    n=""
    d=""
    def extended_gcd(self,a, b):
        if a == 0:
            return b, 0, 1
        else:
            g, x, y = self.extended_gcd(self,b % a, a)
            return g, y - (b // a) * x, x

    def modinv(self,a, m):
        g, x, _ = self.extended_gcd(self,a, m)
        if g != 1:
            raise Exception('Modular inverse does not exist')
        else:
            return x % m

    def c_calculation(m, e, n):
        binary_representation = bin(e)[2:]

        result = 1
        for digit in reversed(binary_representation):
            result = (result * result) % n
            if digit == '1':
                result = (result * m) % n

        return result

    def is_prime(num):    
        if num < 2:
            return False
        for i in range(2, int(num**0.5) + 1):
            if num % i == 0:
                return False
        return True

    def generate_random_prime(self):
        while True:
            num = random.randint(101, 1000)  
            if self.is_prime(num):
                return num

    def generate_random_e(self,phin):
        while True:
            e = random.randint(2, phin - 1)
            if self.extended_gcd(self,e, phin)[0] == 1:
                return e


    def encrypt(self,msg,ttp):
                
        self.n = ttp.p * ttp.q

        phin = (ttp.p - 1) * (ttp.q - 1)
        # self.generate_random_e(self,phin) 
        e =  7
        self.d = self.modinv(self,e, phin)    
        pu = (e, self.n)
        pr = (self.d, self.n)        
        m = msg
        ciphertext = self.c_calculation(m, e, self.n)
        return ciphertext

    def decrypt(cipher,d,n):
        m=pow(cipher,d,n)
        return m
class DES_Algorithm:
  s_box = [
    [[14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7],
      [0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8],
      [4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0],
      [15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13]],
    [[15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10],
      [3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5],
      [0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15],
      [13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9]],
    [[10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8],
      [13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1],
      [13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7],
      [1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12]],
    [[7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15],
      [13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9],
      [10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4],
      [3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14]],
    [[2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9],
      [14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6],
      [4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14],
      [11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3]],
    [[12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11],
      [10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8],
      [9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6],
      [4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13]],
    [[4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1],
      [13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6],
      [1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2],
      [6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12]],
    [[13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7],
      [1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2],
      [7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8],
      [2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11]]
  ]

  shift_table=[1, 1, 2, 2, 
              2, 2, 2, 2, 
              1, 2, 2, 2, 
              2, 2, 2, 1 ] 

  initial_perm = [58, 50, 42, 34, 26, 18, 10, 2,  
                  60, 52, 44, 36, 28, 20, 12, 4,  
                  62, 54, 46, 38, 30, 22, 14, 6,  
                  64, 56, 48, 40, 32, 24, 16, 8,  
                  57, 49, 41, 33, 25, 17, 9, 1,  
                  59, 51, 43, 35, 27, 19, 11, 3,  
                  61, 53, 45, 37, 29, 21, 13, 5,  
                  63, 55, 47, 39, 31, 23, 15, 7]  

  perm_cho_1= [57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18,
              10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36,
              63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22,
              14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20, 12, 4]

  perm_cho_2= [14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10,
              23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2,
              41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48,
              44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32]

  expan_perm=[32, 1, 2, 3, 4, 5,
              4, 5, 6, 7, 8, 9,
              8, 9, 10, 11, 12, 13,
              12, 13, 14, 15, 16, 17, 
              16, 17, 18, 19, 20, 21,
              20, 21, 22, 23, 24, 25,
              24, 25, 26, 27, 28, 29,
              28, 29, 30, 31, 32, 1]

  perm_table=[16, 7, 20, 21, 29, 12, 28, 17,
              1, 15, 23, 26, 5, 18, 31, 10,
              2, 8, 24, 14, 32, 27, 3, 9,
              19, 13, 30, 6, 22, 11, 4, 25]

  final_perm = [40, 8, 48, 16, 56, 24, 64, 32, 
                39, 7, 47, 15, 55, 23, 63, 31, 
                38, 6, 46, 14, 54, 22, 62, 30,
                37, 5, 45, 13, 53, 21, 61, 29, 
                36, 4, 44, 12, 52, 20, 60, 28, 
                35, 3, 43, 11, 51, 19, 59, 27, 
                34, 2, 42, 10, 50, 18, 58, 26, 
                33, 1, 41, 9, 49, 17, 57, 25 ] 
  def xor(a,b): 
    ans="" 
    for i in range(len(a)): 
      if(a[i]==b[i]): 
        ans=ans+"0"
      else: 
        ans=ans+"1"
    return ans

  def hexa_to_bin(msg): 
    mp = {'0' : "0000",  
          '1' : "0001", 
          '2' : "0010",  
          '3' : "0011", 
          '4' : "0100", 
          '5' : "0101",  
          '6' : "0110", 
          '7' : "0111",  
          '8' : "1000", 
          '9' : "1001",  
          'A' : "1010", 
          'B' : "1011",  
          'C' : "1100", 
          'D' : "1101",  
          'E' : "1110", 
          'F' : "1111",
          'a' : "1010", 
          'b' : "1011",  
          'c' : "1100", 
          'd' : "1101",  
          'e' : "1110", 
          'f' : "1111"  } 
    bin = "" 
    for i in range(len(msg)): 
      bin = bin + mp[msg[i]] 
    return bin
          
  def bin_to_hexa(msg): 
    mp = {"0000" : '0',  
          "0001" : '1', 
          "0010" : '2',  
          "0011" : '3', 
          "0100" : '4', 
          "0101" : '5',  
          "0110" : '6', 
          "0111" : '7',  
          "1000" : '8', 
          "1001" : '9',  
          "1010" : 'A', 
          "1011" : 'B',  
          "1100" : 'C', 
          "1101" : 'D',  
          "1110" : 'E', 
          "1111" : 'F' } 
    hex="" 
    for i in range(0,len(msg),4): 
      ch="" 
      ch=ch+msg[i] 
      ch=ch+msg[i+1]  
      ch=ch+msg[i+2]  
      ch=ch+msg[i+3]  
      hex=hex+mp[ch] 
    return hex
        
  def bin_to_dec(msg):  
    decimal,i=0,0
    while(msg!=0):  
      dec=msg%10
      decimal=decimal+dec*pow(2, i)  
      msg=msg//10
      i+=1
    return decimal 
        
  def dec_to_bin(num):  
    res=bin(num).replace("0b", "") 
    if(len(res)%4 != 0): 
      div=len(res) / 4
      div=int(div) 
      counter=(4*(div+1))-len(res)  
      for i in range(0, counter): 
        res='0'+res 
    return res

  def shift_left(key,nth_shifts): 
    s="" 
    for i in range(nth_shifts): 
      for j in range(1,len(key)): 
        s=s+key[j] 
      s=s+key[0] 
      key=s 
      s=""  
    return key

  def initial_permutation(plain_text,initial_perm, no_bits): 
    permutation="" 
    
    for i in range(0,no_bits): 
      permutation=permutation+plain_text[initial_perm[i]-1] 
    return permutation 


  def pad(msg):
    if(len(msg)%16!=0):      
      for i in range(abs(16-(len(msg)%16))):
        msg=msg+'0'     
    return(msg)


  def encrypt(self,msg,key):
    msg=self.hexa_to_bin(msg)
    msg = self.initial_permutation(msg, self.initial_perm, 64) 
    key = self.hexa_to_bin(key) 

    key = self.initial_permutation(key, self.perm_cho_1, 56)
    l=key[0:28]
    r=key[28:56]
    left = msg[0:32] 
    right =msg[32:64] 

    key_from_pc2_bin=[]
    key_from_pc2_hex=[]
    for k in range(16):
      l=self.shift_left(l,self.shift_table[k])
      r=self.shift_left(r,self.shift_table[k])
      combine_key=l+r
      
      round_key=self.initial_permutation(combine_key,self.perm_cho_2,48)
      key_from_pc2_bin.append(round_key)
      key_from_pc2_hex.append(self.bin_to_hexa(round_key))
    
    for j in range(16):
      right_expand=self.initial_permutation(right,self.expan_perm,48)
      xor_x=self.xor(right_expand,key_from_pc2_bin[j])

      s_box_str="" 
      for i in range(0,8):
        row=self.bin_to_dec(int(xor_x[i*6]+xor_x[i*6+5]))
        col=self.bin_to_dec(int(xor_x[i*6+1]+xor_x[i*6+2]+xor_x[i*6+3]+xor_x[i*6+4]))
        val=self.s_box[i][row][col]
        s_box_str=s_box_str+self.dec_to_bin(val)

      s_box_str=self.initial_permutation(s_box_str,self.perm_table,32)

      result=self.xor(left,s_box_str)
      left=result
      
      if(j!=15):
        left, right=right, left

    combine=left+right
    cipher_text=self.initial_permutation(combine,self.final_perm,64)
    return cipher_text

  def decrypt(self,msg,key):
    msg=self.hexa_to_bin(msg)
    msg = self.initial_permutation(msg, self.initial_perm, 64) 
    key = self.hexa_to_bin(key) 

    key = self.initial_permutation(key, self.perm_cho_1, 56)
    l=key[0:28]
    r=key[28:56]
    left = msg[0:32] 
    right =msg[32:64] 

    key_from_pc2_bin=[]
    key_from_pc2_hex=[]
    for k in range(16):
      l=self.shift_left(l,self.shift_table[k])
      r=self.shift_left(r,self.shift_table[k])
      combine_key=l+r
      
      round_key=self.initial_permutation(combine_key,self.perm_cho_2,48)
      key_from_pc2_bin.append(round_key)
      key_from_pc2_hex.append(self.bin_to_hexa(round_key))

    key_from_pc2_bin=key_from_pc2_bin[::-1]
    key_from_pc2_hex=key_from_pc2_hex[::-1]  
    
    for j in range(16):
      right_expand=self.initial_permutation(right,self.expan_perm,48)
      xor_x=self.xor(right_expand,key_from_pc2_bin[j])

      s_box_str="" 
      for i in range(0,8):
        row=self.bin_to_dec(int(xor_x[i*6]+xor_x[i*6+5]))
        col=self.bin_to_dec(int(xor_x[i*6+1]+xor_x[i*6+2]+xor_x[i*6+3]+xor_x[i*6+4]))
        val=self.s_box[i][row][col]
        s_box_str=s_box_str+self.dec_to_bin(val)

      s_box_str=self.initial_permutation(s_box_str,self.perm_table,32)

      result=self.xor(left,s_box_str)
      left=result
      
      if(j!=15):
        left, right=right, left

    combine=left+right
    decryption_text=self.initial_permutation(combine,self.final_perm,64)
    return decryption_text
class Vigenere_Algorithm:
    #decryption
    def generate_alphabet():
    
        return ''.join(chr(ord('a') + i) for i in range(26))

    def generate_key(keyword, length):
    
        keyword = keyword.lower()
        key = ''
        keyword_index = 0
        for i in range(length):
            key += keyword[keyword_index]
            keyword_index = (keyword_index + 1) % len(keyword)
        return key

    def decrypt(self,cipher_text, key):
        index = 0
        plain_text = ""

        
        main = self.generate_alphabet()

        for c in cipher_text:
            if c in main:
                
                off = ord(key[index]) - ord('a')

                positive_off = 26 - off
                decrypt = chr((ord(c) - ord('a') + positive_off) % 26 + ord('a'))

            
                plain_text += decrypt

            
                index = (index + 1) % len(key)
            else:
                plain_text += c
        
        return plain_text


    def encrypt(self,plain_text, key):
        index = 0
        cipher_text = ""


        main = self.generate_alphabet()

    
        for c in plain_text:
            if c in main:
            
                off = ord(key[index]) - ord('a')
                
            
                encrypt_num = (ord(c) - ord('a') + off) % 26
                encrypt = chr(encrypt_num + ord('a'))
                
                
                cipher_text += encrypt
                
            
                index = (index + 1) % len(key)
        
            else:
                cipher_text += c

        return cipher_text
class Row_Transposition_Algorithm:
    def __init__(self, key, plaintext):
        self.key = key
        self.columns = len(key)
        self.plaintext = plaintext
        self.alphabet = [chr(i) for i in range(ord('A'), ord('Z') + 1)]

    def prepare_input(self, text):
        text = text.replace(" ", "").upper()
        text = text.replace("J", "I")
        return text

    def create_matrix(self, key, plaintext):
        matrix = [list(key)]
        plaintext = self.prepare_input(plaintext.replace(" ", ""))
        matrix += [list(plaintext[i:i + self.columns]) for i in range(0, len(plaintext), self.columns)]
        last_row = matrix[-1]
        last_row_length = len(last_row)
        if last_row_length < self.columns:
            last_row += ['Z'] * (self.columns - last_row_length)
        return matrix

    def create_matrix_dec(self, key, ciphertext):
        key = self.prepare_input(key)
        ciphertext = self.prepare_input(ciphertext)
        columns = len(key)
        rows = len(ciphertext) // columns + (1 if len(ciphertext) % columns != 0 else 0)
        matrix = [[''] * columns for _ in range(rows + 1)]
        key_order = sorted(range(len(key)), key=lambda k: key[k])

        for j in range(columns):
            matrix[0][j] = key[j]

        k = 0
        for j in range(columns):
            original_index = key_order[j]
            for i in range(1, rows + 1):
                if k < len(ciphertext):
                    matrix[i][original_index] = ciphertext[k]
                    k += 1
                else:
                    break

        return matrix

    def read_matrix_by_row(self, matrix):
        result = ""
        for row in matrix[1:]:
            result += ''.join(row)
        return result

    def read_matrix_ordered(self, matrix):
        ordered_result = ''
        key_row = list(map(int, matrix[0]))

        for key_number in range(1, max(key_row) + 1):
            if key_number in key_row:
                key_index = key_row.index(key_number)
                ordered_result += ''.join(matrix[i][key_index] for i in range(1, len(matrix)))

        return ordered_result

    def encrypt(self):
        sorted_key = ''.join(self.key)
        matrix = self.create_matrix(sorted_key, self.plaintext)
        result_ordered = self.read_matrix_ordered(matrix)
        return matrix, result_ordered

    def decrypt(self):
        ciphertext = self.read_matrix_ordered(self.create_matrix(''.join(self.key), self.plaintext))
        matrix_dec = self.create_matrix_dec(self.key, ciphertext)
        output_text = self.read_matrix_by_row(matrix_dec)
        return matrix_dec, output_text
class Monoalphabet_Algorithm:
    def __init__(self, key, plaintext):
        self.alphabet = [chr(i) for i in range(ord('A'), ord('Z')+1)]
        self.key_alphabet = self.encryption_key_alphabet(key)
        self.plaintext = plaintext

    def prepare_input(self, text):
        text = text.replace(" ", "").upper()
        text = text.replace("J", "I")
        return text

    def encryption_key_alphabet(self, key):
        key = self.prepare_input(key)
        unique_chars = list(dict.fromkeys(key))
        remaining_chars = [chr(i) for i in range(ord('A'), ord('Z')+1) if chr(i) not in unique_chars]
        unique_chars.extend(remaining_chars)
        return unique_chars

    def perform_encryption(self):
        plaintext = self.prepare_input(self.plaintext)
        ciphertext = ""

        for char in plaintext:
            if char in self.alphabet:
                index = self.alphabet.index(char)
                ciphertext += self.key_alphabet[index]
            else:
                ciphertext += char

        return ciphertext

    def perform_decryption(self, ciphertext):
        ciphertext = self.prepare_input(ciphertext)
        plaintext = ""

        for char in ciphertext:
            if char in self.key_alphabet:
                index = self.key_alphabet.index(char)
                plaintext += self.alphabet[index]
            else:
                plaintext += char

        return plaintext
class Caesar_Algorithm:
    def __init__(self, text, shift):
        self.text = text
        self.shift = shift

    def encrypt(self):
        shift1 = self.shift
        text = self.text.replace(" ", "")
        result = ""

        for char in text:
            if char.isupper():
                result += chr((ord(char) + shift1 - 65) % 26 + 65)
            else:
                result += chr((ord(char) + shift1 - 97) % 26 + 97)

        return result

    def decrypt(self,cypher):
        shift1 = 26 - self.shift
        result = ""

        for char in cypher:
            if char.isupper():
                result += chr((ord(char) + shift1 - 65) % 26 + 65)
            else:
                result += chr((ord(char) + shift1 - 97) % 26 + 97)

        return result
class Playfair_Algorithm:
    @staticmethod
    def key_generation(key):
        main = "abcdefghiklmnopqrstuvwxyz"
        key = key.lower()
        key_matrix = [['' for _ in range(5)] for _ in range(5)]
        i, j = 0, 0

        for c in key:
            if c in main:
                key_matrix[i][j] = c
                main = main.replace(c, '')
                j += 1
                if j > 4:
                    i += 1
                    j = 0

        for c in main:
            if c != '.':
                key_matrix[i][j] = c
                j += 1
                if j > 4:
                    i += 1
                    j = 0

        return key_matrix

    @staticmethod
    def encrypt(plain_text, key_matrix):
        plain_text_pairs = []
        cipher_text_pairs = []

        plain_text = plain_text.replace(" ", "")
        plain_text = plain_text.lower()

        i = 0

        while i < len(plain_text):
            a = plain_text[i]
            b = ''
            if (i + 1) == len(plain_text):
                b = 'x'
            else:
                b = plain_text[i + 1]

            if a != b:
                plain_text_pairs.append(a + b)
                i += 2
            else:
                plain_text_pairs.append(a + 'x')
                i += 1

        for pair in plain_text_pairs:
            flag = False
            for i in range(5):
                row = key_matrix[i]
                if pair[0] in row and pair[1] in row:
                    j0 = row.index(pair[0])
                    j1 = row.index(pair[1])
                    cipher_text_pair = row[(j0 + 1) % 5] + row[(j1 + 1) % 5]
                    cipher_text_pairs.append(cipher_text_pair)
                    flag = True
            if flag:
                continue

            for j in range(5):
                col = "".join([key_matrix[i][j] for i in range(5)])
                if pair[0] in col and pair[1] in col:
                    i0 = col.index(pair[0])
                    i1 = col.index(pair[1])
                    cipher_text_pair = col[(i0 + 1) % 5] + col[(i1 + 1) % 5]
                    cipher_text_pairs.append(cipher_text_pair)
                    flag = True
            if flag:
                continue

            i0, i1, j0, j1 = 0, 0, 0, 0

            for i in range(5):
                row = key_matrix[i]
                if pair[0] in row:
                    i0, j0 = i, row.index(pair[0])
                if pair[1] in row:
                    i1, j1 = i, row.index(pair[1])

            cipher_text_pair = key_matrix[i0][j1] + key_matrix[i1][j0]
            cipher_text_pairs.append(cipher_text_pair)

        return "".join(cipher_text_pairs)

    @staticmethod
    def decryption(cipher_text, key_matrix):
        plain_text_pairs = []
        cipher_text_pairs = []

        cipher_text = cipher_text.lower()

        i = 0
        while i < len(cipher_text):
            a = cipher_text[i]
            b = cipher_text[i + 1]

            cipher_text_pairs.append(a + b)
            i += 2

        for pair in cipher_text_pairs:
            flag = False
            for i in range(5):
                row = key_matrix[i]
                if pair[0] in row and pair[1] in row:
                    j0 = row.index(pair[0])
                    j1 = row.index(pair[1])
                    plain_text_pair = row[(j0 + 4) % 5] + row[(j1 + 4) % 5]
                    plain_text_pairs.append(plain_text_pair)
                    flag = True
            if flag:
                continue

            for j in range(5):
                col = "".join([key_matrix[i][j] for i in range(5)])
                if pair[0] in col and pair[1] in col:
                    i0 = col.index(pair[0])
                    i1 = col.index(pair[1])
                    plain_text_pair = col[(i0 + 4) % 5] + col[(i1 + 4) % 5]
                    plain_text_pairs.append(plain_text_pair)
                    flag = True
            if flag:
                continue

            i0, i1, j0, j1 = 0, 0, 0, 0

            for i in range(5):
                row = key_matrix[i]
                if pair[0] in row:
                    i0, j0 = i, row.index(pair[0])
                if pair[1] in row:
                    i1, j1 = i, row.index(pair[1])

            plain_text_pair = key_matrix[i0][j1] + key_matrix[i1][j0]
            plain_text_pairs.append(plain_text_pair)

        return "".join(plain_text_pairs)
class RailFence_Algorithm:
    def __init__(self, key):
        self.key = key

    def encrypt(self, plaintext):
        plaintext = plaintext.replace(" ", "").upper()
        fence = ['' for _ in range(self.key)]

        direction = 1  # 1 for down, -1 for up
        row = 0

        for char in plaintext:
            fence[row] += char
            row += direction

            if row == self.key - 1 or row == 0:
                direction *= -1

        ciphertext = ''.join(fence)
        return ciphertext

    def decrypt(self, ciphertext):
        ciphertext = ciphertext.replace(" ", "").upper()
        fence = ['' for _ in range(self.key)]

        direction = 1
        row = 0

        for char in ciphertext:
            fence[row] += '*'
            row += direction

            if row == self.key - 1 or row == 0:
                direction *= -1

        index = 0
        for i in range(self.key):
            for j in range(len(fence[i])):
                fence[i] = fence[i][:j] + ciphertext[index] + fence[i][j + 1:]
                index += 1

        plaintext = ''
        direction = 1
        row = 0

        for i in range(len(ciphertext)):
            plaintext += fence[row][0]
            fence[row] = fence[row][1:]
            row += direction

            if row == self.key - 1 or row == 0:
                direction *= -1

        return plaintext









