def prepare_input(text):
    text = text.replace(" ", "").upper()
    text = text.replace("J", "I")
    return text

def encryption_key_alphabet(key):
    key = prepare_input(key)
    unique_chars = list(dict.fromkeys(key))
    remaining_chars = [chr(i) for i in range(ord('A'), ord('Z')+1) if chr(i) not in unique_chars]
    unique_chars.extend(remaining_chars)
    return unique_chars

def perform_encryption(plaintext, key_alphabet):
    plaintext = prepare_input(plaintext)
    ciphertext = ""

    for char in plaintext:
        if char in alphabet:
            # Find the index of the character in the alphabet
            index = alphabet.index(char)
            # Append the corresponding character below the alphabet to the ciphertext
            ciphertext += key_alphabet[index]  # No shift is applied here
        else:
            # If the character is not in the alphabet, append it as is
            ciphertext += char

    return ciphertext

def perform_decryption(ciphertext, key_alphabet):
    ciphertext = prepare_input(ciphertext)
    plaintext = ""

    for char in ciphertext:
        if char in key_alphabet:
            # Find the index of the character in the key_alphabet
            index = key_alphabet.index(char)
            # Append the corresponding character above the key_alphabet to the plaintext
            plaintext += alphabet[index]  # No shift is applied here
        else:
            # If the character is not in the key_alphabet, append it as is
            plaintext += char

    return plaintext

# Example usage:
key = "when you want something all the universe conspires in helping you to achieve it"
plaintext = "I am going far"

# Step 1: Write down the alphabets
alphabet = [chr(i) for i in range(ord('A'), ord('Z')+1)]

# Step 2: Sort the key under the alphabets
key_alphabet = encryption_key_alphabet(key)

# Print the result of Step 1 and Step 2
print("alphabet :",alphabet)
print("--------------------------------------------")
print("Key :",key_alphabet)

# Step 3: Perform encryption
ciphertext = perform_encryption(plaintext, key_alphabet)

# Print the result of Step 3
print("\nPlaintext:", plaintext)
print("Ciphertext:", ciphertext)



# Step 4: Perform decryption
decrypted_text = perform_decryption(ciphertext, key_alphabet)

# Print the result of Step 4
print("\nDecrypted Text:", decrypted_text)