key = '4312567'
columns = 7
plaintext = "attack postponed until two am"
def prepare_input(text):
    text = text.replace(" ", "").upper()
    text = text.replace("J", "I")
    return text


def create_matrix(key, plaintext):
    
    # Create the first row of the matrix with key numbers
    matrix = [list(key)]

    # Write plaintext letters in the remaining rows without spaces
    plaintext = prepare_input(plaintext.replace(" ", ""))
    
    matrix += [list(plaintext[i:i+columns]) for i in range(0, len(plaintext), columns)]
    # Fill empty cells with x characters from the alphabet
    last_row = matrix[-1]
    last_row_length = len(last_row)
    if last_row_length < columns:
        last_row += ['Z'] * (columns - last_row_length)

    return matrix
# Example usage:

def create_matrix_dec(key, ciphertext):
    key = prepare_input(key)
    ciphertext = prepare_input(ciphertext)

    # Calculate the number of columns based on the length of the key
    columns = len(key)

    # Calculate the number of rows based on the length of the ciphertext and the number of columns
    rows = len(ciphertext) // columns + (1 if len(ciphertext) % columns != 0 else 0)

    # Create an empty matrix with an additional row for the key
    matrix = [[''] * columns for _ in range(rows + 1)]

    # Sort the key and create a mapping of the original index to the sorted index
    key_order = sorted(range(len(key)), key=lambda k: key[k])

    # Fill the first row with the sorted key
    for j in range(columns):
        matrix[0][j] = key[j]

    # Fill the matrix with the ciphertext by column, starting from the second row
    k = 0
    for j in range(columns):
        original_index = key_order[j]
        for i in range(1, rows + 1):
            if k < len(ciphertext):
                matrix[i][original_index] = ciphertext[k]
                k += 1
            else:
                break

    return matrix

def read_matrix_by_row(matrix):
    result = ""
    for row in matrix[1:]:
        result += ''.join(row)
    return result


def read_matrix_ordered(matrix):
    ordered_result = ''
    key_row = list(map(int, matrix[0]))  # Convert key numbers to integers

    for key_number in range(1, max(key_row) + 1):  # Iterate from 1 to the maximum key number
        if key_number in key_row:  # Check if the key number is present in the key_row
            key_index = key_row.index(key_number)  # Find the index of the key number
            ordered_result += ''.join(matrix[i][key_index] for i in range(1, len(matrix)))

    return ordered_result


# Step 1: Write down the alphabets
alphabet = [chr(i) for i in range(ord('A'), ord('Z')+1)]

# Step 2: Sort the key under the alphabets
sorted_key = ''.join(key)

# Print the result of Step 1 and Step 2
print("Alphabet:", alphabet)
print("Key:", sorted_key)

# Step 3: Create a matrix based on the sorted key
matrix = create_matrix(sorted_key,plaintext)


# Print the result of Step 3
print("\nMatrix:")
for row in matrix:
    print(row)

# Print the result of Step 4
print("\nPlaintext:", plaintext)
result_ordered = read_matrix_ordered(matrix)
print("\nEncryption:", result_ordered)



ciphertext=result_ordered


matrix_dec = create_matrix_dec(key, ciphertext)

# Call the function with the matrix created earlier
output_text = read_matrix_by_row(matrix_dec)


# Print the resulting matrix
for row_dec in matrix_dec:
    print(row_dec)

# Print the resulting output text
print("\nDecryption:",output_text)
