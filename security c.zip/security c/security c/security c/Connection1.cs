﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace security_c
{
    public class ClientC
    {
        NetworkStream stream;
        TcpClient tcpClient;
        public string message = "";
        public Boolean isConnected = false;
        public string textrecieve = "";
        public int type = 0;
        public bool connectToSocket(String host, int portNumber)
        {
            try
            {
                tcpClient = new TcpClient(host, portNumber);
                stream = tcpClient.GetStream();
                Console.WriteLine("Connection Made ! with " + host);
                isConnected = true;                
                return true;
            }
            catch (System.Net.Sockets.SocketException e)
            {
                MessageBox.Show("An error occurred: " + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public bool recieveMessage()
        {
            try
            {
                byte[] recieveBuffer = new byte[1024];
                int bytesReceived = stream.Read(recieveBuffer, 0, recieveBuffer.Length);
                string data = Encoding.UTF8.GetString(recieveBuffer, 0, bytesReceived);
                string[] points = data.Split(',');

                for (int i = 0; i < points.Length; i++)
                {
                    if (points[i] != "")
                    {
                        textrecieve = points[i];
                        Console.WriteLine(points[i]);
                    }                   
                }

                return true;
            }
            catch (System.Net.Sockets.SocketException e)
            {
                Console.WriteLine("Connection failed:" + e);
                return false;
            }
        }

        public void SendMessage()
        {
            NetworkStream stream = tcpClient.GetStream();
            string[] data = new string[] { message, "" + type };

            // Concatenate the strings with no separator
            string message_s = string.Concat(data[0], data[1]);

            // Convert the concatenated string to bytes
            byte[] byteData = Encoding.UTF8.GetBytes(message_s);

            // Send the data
            stream.Write(byteData, 0, byteData.Length);

            Console.WriteLine($"Sent message: {message_s}");

        }

        public bool closeConnection()
        {
            stream.Close();
            tcpClient.Close();
            Console.WriteLine("connection terminated");
            return true;
        }
    }
}
