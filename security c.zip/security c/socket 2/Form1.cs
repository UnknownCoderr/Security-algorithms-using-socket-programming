﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Threading;

namespace socket_2
{
    public partial class Form1 : Form
    {
        public ClientC c = new ClientC();
        int i = 0;
        Thread thread1;
        public Form1()
        {
            InitializeComponent();
            c.connectToSocket("localhost", 5000);
            thread1 = new Thread(recive);
            thread1.Start();

        }
        void recive()
        {
            while (true)
            {
                if (c.recieveMessage())
                    this.Invoke((MethodInvoker)delegate
                    {
                        label1.Text += "Sender: " + c.textrecieve + "\n";
                    });


            }
           
            //Thread.Sleep(500);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.comboBox1.Items.Add("Playfair");
            this.comboBox1.Items.Add("AES");
            this.comboBox1.Items.Add("RC4");
            this.comboBox1.Items.Add("El Gamal");
            this.comboBox1.Items.Add("RSA");
            this.comboBox1.Items.Add("DES");
            this.comboBox1.Items.Add("Vigenere");
            this.comboBox1.Items.Add("Row_Transposition");
            this.comboBox1.Items.Add("Monoalphabet");
            this.comboBox1.Items.Add("Ceaser");
            //this.comboBox1.Items.Add("RailFence");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Use Encrypt method fitst ???");
            }
            if (textBox1.Text == "")
            {
                MessageBox.Show("Enter The Message");
            }
            if (textBox1.Text != ""&& comboBox1.SelectedIndex!=-1)
            {                
                c.message = textBox1.Text;
                c.type = comboBox1.SelectedIndex;
                label1.Text += "You: " + c.message + "\n";
                c.SendMessage();
                textBox1.Clear();

                //for (int i = 0; i < c.textrecieve.Count; i++)
                //{
                //    label1.Text = "sender: " + string.Join(Environment.NewLine, c.textrecieve[i]);
                //}
            }
        }
    }
}
