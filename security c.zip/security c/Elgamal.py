def encrypt_decrypt(q, a, xA, M, k):
    # Calculate public key ya = a^xa mod q
    ya = pow(a, xA, q)

    # Calculate k_new = ya^k mod q
    k_new = pow(ya, k, q)

    # Calculate C1 = a^k mod q
    c1 = pow(a, k, q)

    # Calculate C2 = KM mod q
    c2 = (k_new * M) % q

    # Verify k_new
    k_t2ked = pow(c1, xA, q)
    if k_t2ked == k_new:
        print("Encryption successful")
    else:
        print("Encryption failed")

    # Calculate the modular inverse of k_new
    k_1 = pow(k_new, -1, q)

    # Decrypt to obtain M_t2ked = C2 * k_1 mod q
    M_t2ked = (c2 * k_1) % q

    # Verify decryption
    if M_t2ked == M:
        print("Decryption successful")
    else:
        print("Decryption failed")

    return M_t2ked

# Example usage
q = 19
a = 10
xA = 5
k = 6
M = 17

result = encrypt_decrypt(q, a, xA, M, k)
print(f"Result: {result}")
